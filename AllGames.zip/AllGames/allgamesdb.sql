drop database if exists allgames;

create database allgames;

use allgames;

CREATE TABLE users (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL,
  cpf varchar(45) NOT NULL,
  email varchar(255) NOT NULL,
  age int NOT NULL,
  password_hash varchar(255) NOT NULL,
  created_at timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY cpf (cpf),
  UNIQUE KEY email (email)
);

CREATE TABLE wallets (
  user_id int NOT NULL,
  balance decimal(10,2) NOT NULL DEFAULT '0.00',
  created_at timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_wallet_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT ck_balance_non_negative CHECK ((balance >= 0))
);

CREATE TABLE velha_scores (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NOT NULL,
  difficulty enum('facil','medio','dificil') DEFAULT NULL,
  points int NOT NULL DEFAULT '0',
  created_at datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  CONSTRAINT velha_scores_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE TABLE sudoku_scores (
  id int NOT NULL AUTO_INCREMENT,
  user_id int DEFAULT NULL,
  difficulty enum('facil','medio','dificil') DEFAULT NULL,
  points int DEFAULT '0',
  created_at datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  CONSTRAINT sudoku_scores_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE TABLE player_scores (
  user_id int NOT NULL,
  total_points int NOT NULL DEFAULT '0',
  updated_at timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_score_user FOREIGN KEY (user_id) REFERENCES users (id),
  CONSTRAINT ck_points_non_negative CHECK ((total_points >= 0))
);

CREATE TABLE fourline_scores (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NOT NULL,
  difficulty enum('facil','medio','dificil') DEFAULT NULL,
  points int NOT NULL DEFAULT '0',
  created_at datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  CONSTRAINT fourline_scores_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE TABLE dama_scores (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NOT NULL,
  difficulty enum('facil','medio','dificil') DEFAULT NULL,
  points int NOT NULL DEFAULT '0',
  created_at datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  CONSTRAINT dama_scores_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE TABLE chess_scores (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NOT NULL,
  difficulty enum('facil','medio','dificil') DEFAULT NULL,
  points int NOT NULL DEFAULT '0',
  created_at datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  CONSTRAINT chess_scores_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (id)
);
