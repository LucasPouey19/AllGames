const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Lucas@19',
    database: 'allgames'
});

connection.connect((err) => {
    if (err) {
        throw err;
    } else {
        console.log('Vamo Grêmio')
    }
});9

module.exports = connection;

// Função para somar os pontos de todas as tabelas e atualizar o total
function atualizarPontuacaoTotal(userId, res, callback) {
    const somaTotalQuery = `
        SELECT 
            (SELECT IFNULL(SUM(points), 0) FROM sudoku_scores WHERE user_id = ?) AS sudokuTotal,
            (SELECT IFNULL(SUM(points), 0) FROM chess_scores WHERE user_id = ?) AS chessTotal,
            (SELECT IFNULL(SUM(points), 0) FROM velha_scores WHERE user_id = ?) AS velhaTotal,
            (SELECT IFNULL(SUM(points), 0) FROM dama_scores WHERE user_id = ?) AS damaTotal
            (SELECT IFNULL(SUM(points), 0) FROM fourline_scores WHERE user_id = ?) AS fourlineTotal
    `;

    connection.query(somaTotalQuery, [userId, userId, userId, userId, userId], (err, results) => {
        if (err) {
            console.error("Erro ao somar pontuações:", err);
            return res.status(500).json({ message: "Erro ao calcular pontuação total." });
        }

        const sudokuTotal = Number(results[0].sudokuTotal) || 0;
        const chessTotal = Number(results[0].chessTotal) || 0;
        const velhaTotal = Number(results[0].velhaTotal) || 0;
        const damaTotal = Number(results[0].damaTotal) || 0;
        const fourlineTotal = Number(results[0].damaTotal) || 0;


        const total = Math.max(0, sudokuTotal + chessTotal + velhaTotal + damaTotal + fourlineTotal);

        const updateTotalQuery = `
            INSERT INTO player_scores (user_id, total_points)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE total_points = VALUES(total_points)
        `;

        connection.query(updateTotalQuery, [userId, total], (err) => {
            if (err) {
                console.error("Erro ao atualizar total_points:", err);
                return res.status(500).json({ message: "Erro ao atualizar pontos totais." });
            }

            if (callback) {
                callback(total);
            } else {
                res.status(200).json({ message: "Pontuação salva e total atualizada com sucesso.", total });
            }
        });
    });
}


//  --- Server ---

const express = require("express");
const cors = require("cors");

const port = 3005;


const app = express();

app.use(cors());
app.use(express.json());

app.listen(port, () => console.log(`Quantidade de bola de ouro do Jemerson: ${port}`));

// Rota para cadastrar o usuário (sem bcrypt)
app.post("/cadastro", (req, res) => {
    const { name, cpf, email, age, password } = req.body;

    if (!name || !cpf || !email || !age || !password) {
        return res.status(400).json({ message: "Preencha todos os campos." });
    }

    const sqlInsertUser = `
        INSERT INTO users (name, cpf, email, age, password_hash)
        VALUES (?, ?, ?, ?, ?)
    `;

    connection.query(
        sqlInsertUser,
        [name, cpf, email, age, password], // senha pura (não recomendado para produção)
        (err, result) => {
            if (err) {
                if (err.code === "ER_DUP_ENTRY") {
                    return res.status(409).json({ message: "Email ou CPF já cadastrado." });
                }
                console.error("Erro ao cadastrar:", err);
                return res.status(500).json({ message: "Erro interno no servidor." });
            }

            const userId = result.insertId;

            // Cria entrada na carteira com saldo 0
            connection.query(
                "INSERT INTO wallets (user_id, balance) VALUES (?, ?)",
                [userId, 0],
                (err) => {
                    if (err) console.error("Erro ao inserir na carteira:", err);
                }
            );

            // Cria entrada nos pontos com 0 pontos
            connection.query(
                "INSERT INTO player_scores (user_id, total_points) VALUES (?, ?)",
                [userId, 0],
                (err) => {
                    if (err) console.error("Erro ao inserir nos pontos:", err);
                }
            );

            res.status(201).json({ message: "Usuário cadastrado com sucesso!" });
        }
    );
});

// Rota de login
app.post("/login", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "Email e senha são obrigatórios." });
    }

    const sql = "SELECT * FROM users WHERE email = ? AND password_hash = ?";

    connection.query(sql, [email, password], (err, results) => {
        if (err) {
            console.error("Erro ao fazer login:", err);
            return res.status(500).json({ message: "Erro interno no servidor." });
        }

        if (results.length === 0) {
            return res.status(401).json({ message: "Email ou senha incorretos." });
        }

        const user = results[0];

        res.status(200).json({
            message: "Login bem-sucedido!",
            user: {
                id: user.id,
                name: user.name,
                email: user.email
            }
        });
    });
});

/* ---------- WALLET ROUTES ---------- */

// 1) Consultar saldo
app.get("/wallet/:userId", (req, res) => {
    const { userId } = req.params;

    connection.query(
        "SELECT balance FROM wallets WHERE user_id = ?",
        [userId],
        (err, results) => {
            if (err) return res.status(500).json({ message: "Erro de servidor." });
            if (results.length === 0)
                return res.status(404).json({ message: "Usuário sem carteira." });

            res.json({ balance: results[0].balance });
        }
    );
});

// 2) Definir saldo inicial (só se balance==0)
app.post("/wallet/:userId", (req, res) => {
    const { userId } = req.params;
    const { initialBalance } = req.body;
    const allowed = [5, 10, 25, 50, 100, 150];

    if (!allowed.includes(initialBalance))
        return res.status(400).json({ message: "Valor inicial inválido." });

    // Tenta atualizar APENAS se balance ainda for 0
    const sql = `
        UPDATE wallets
        SET balance = ?
        WHERE user_id = ? AND balance = 0
    `;

    connection.query(sql, [initialBalance, userId], (err, result) => {
        if (err) return res.status(500).json({ message: "Erro de servidor." });

        if (result.affectedRows === 0) {
            return res
                .status(409)
                .json({ message: "Saldo já definido anteriormente." });
        }

        res.status(200).json({ message: "Saldo inicial definido!" });
    });
});

// Rota para registrar pontuação do Sudoku
app.post("/sudoku/score", (req, res) => {
    const { userId, difficulty, points } = req.body;

    if (!userId || !difficulty || typeof points !== 'number') {
        return res.status(400).json({ message: "Dados incompletos ou inválidos." });
    }

    const insertQuery = `
        INSERT INTO sudoku_scores (user_id, difficulty, points, created_at)
        VALUES (?, ?, ?, NOW())
    `;

    connection.query(insertQuery, [userId, difficulty, points], (err) => {
        if (err) {
            console.error("Erro ao inserir pontuação do Sudoku:", err);
            return res.status(500).json({ message: "Erro ao salvar pontuação." });
        }

        atualizarPontuacaoTotal(userId, res);
    });
});

app.post("/chess/score", (req, res) => {
    const { userId, dificuldade, pontos } = req.body;

    if (!userId || !dificuldade || typeof pontos !== 'number') {
        return res.status(400).json({ message: "Dados incompletos ou inválidos." });
    }

    const insertQuery = `
        INSERT INTO chess_scores (user_id, difficulty, points, created_at)
        VALUES (?, ?, ?, NOW())
    `;

    connection.query(insertQuery, [userId, dificuldade, pontos], (err) => {
        if (err) {
            console.error("Erro ao inserir pontuação do Xadrez:", err);
            return res.status(500).json({ message: "Erro ao salvar pontuação." });
        }

        atualizarPontuacaoTotal(userId, res);
    });
});

app.post("/velha/score", (req, res) => {
    const { userId, dificuldade, pontos } = req.body;

    if (!userId || !dificuldade || typeof pontos !== 'number') {
        return res.status(400).json({ message: "Dados incompletos ou inválidos." });
    }

    const insertQuery = `
        INSERT INTO velha_scores (user_id, difficulty, points, created_at)
        VALUES (?, ?, ?, NOW())
    `;

    connection.query(insertQuery, [userId, dificuldade, pontos], (err) => {
        if (err) {
            console.error("Erro ao inserir pontuação da Velha:", err);
            return res.status(500).json({ message: "Erro ao salvar pontuação." });
        }

        atualizarPontuacaoTotal(userId, res);
    });
});

app.post("/dama/score", (req, res) => {
    const { userId, dificuldade, pontos } = req.body;

    if (!userId || !dificuldade || typeof pontos !== 'number') {
        return res.status(400).json({ message: "Dados incompletos ou inválidos." });
    }

    const insertQuery = `
        INSERT INTO dama_scores (user_id, difficulty, points, created_at)
        VALUES (?, ?, ?, NOW())
    `;

    connection.query(insertQuery, [userId, dificuldade, pontos], (err) => {
        if (err) {
            console.error("Erro ao inserir pontuação da Dama:", err);
            return res.status(500).json({ message: "Erro ao salvar pontuação." });
        }

        atualizarPontuacaoTotal(userId, res);
    });
});

app.post("/fourline/score", (req, res) => {
    const { userId, dificuldade, pontos } = req.body;

    if (!userId || !dificuldade || typeof pontos !== 'number') {
        return res.status(400).json({ message: "Dados incompletos ou inválidos." });
    }

    const insertQuery = `
        INSERT INTO fourline_scores (user_id, difficulty, points, created_at)
        VALUES (?, ?, ?, NOW())
    `;

    connection.query(insertQuery, [userId, dificuldade, pontos], (err) => {
        if (err) {
            console.error("Erro ao inserir pontuação da Dama:", err);
            return res.status(500).json({ message: "Erro ao salvar pontuação." });
        }

        atualizarPontuacaoTotal(userId, res);
    });
});

app.get('/usuarios/:id/pontos', (req, res) => {
    const userId = req.params.id;

    const query = 'SELECT total_points FROM player_scores WHERE user_id = ?';

    connection.query(query, [userId], (err, results) => {
        if (err) {
            return res.status(500).json({ erro: 'Erro no servidor' });
        }

        if (results.length === 0) {
            return res.status(404).json({ erro: 'Usuário não encontrado' });
        }

        res.json({ pontos: results[0].total_points });
    });
});

app.post('/usuarios/:id/pontos', (req, res) => {
    const userId = req.params.id;
    const { pontos } = req.body; // pontos pode ser positivo (vitória) ou negativo (derrota)

    const query = 'UPDATE player_scores SET total_points = total_points + ? WHERE user_id = ?';

    connection.query(query, [pontos, userId], (err, results) => {
        if (err) {
            return res.status(500).json({ erro: 'Erro ao atualizar pontos' });
        }

        if (results.affectedRows === 0) {
            return res.status(404).json({ erro: 'Usuário não encontrado' });
        }

        res.json({ mensagem: 'Pontos atualizados com sucesso' });
    });
});


