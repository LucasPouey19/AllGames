function backHome() {
    window.location.href = "../inicial/index.html";
}

async function cadastro() {
    const name = document.getElementById('nome').value;
    const cpf = document.getElementById('cpf').value;
    const email = document.getElementById('email').value;
    const age = parseInt(document.getElementById('idade').value);
    const password = document.getElementById('senha').value;

    const user = { name, cpf, email, age, password };

    const res = await fetch("http://localhost:3005/cadastro", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
    });

    const data = await res.json();

    if (res.ok) {
        alert("Cadastro realizado com sucesso!");
        window.location.href = "../login/login.html";
    } else {
        alert("Erro no cadastro: " + data.message);
    }
}
