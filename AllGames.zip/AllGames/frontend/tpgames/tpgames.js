// Executa assim que a página carrega
window.addEventListener("DOMContentLoaded", async () => {
    const name = localStorage.getItem("userName");
    if (name) document.getElementById("name").textContent = `Olá, ${name}!`;
});

// Botão “Apostas”
async function playBet() {
    const userId = localStorage.getItem("userId");
    if (!userId) return alert("Usuário não logado.");

    try {
        const res = await fetch(`http://localhost:3005/wallet/${userId}`);
        const data = await res.json();

        if (!res.ok) throw new Error(data.message);

        if (data.balance === 0) {
            window.location.href = "../tpgames/aposta/inicialaposta/inicialaposta.html";
        } else {
            window.location.href = "../tpgames/aposta/apostahome/apostahome.html";
        }
    } catch (err) {
        alert("Erro ao verificar saldo: " + err.message);
    }
}

// Botão “Jogos” (mantive simples)
function playGame() {
    window.location.href = "../tpgames/jogos/jogoshome/jogoshome.html";
}

// Voltar
function backHome() {
    window.location.href = "../inicial/index.html";
}
