function backHome() {
    window.location.href = "../../../inicial/index.html";
}

async function startPlay(valor) {
    const userId = localStorage.getItem("userId");
    if (!userId) return alert("Usuário não logado.");

    try {
        const res = await fetch(`http://localhost:3005/wallet/${userId}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ initialBalance: valor })
        });
        const data = await res.json();

        if (!res.ok) throw new Error(data.message);

        alert("Saldo definido com sucesso!");
        window.location.href = "../menuaposta/menuaposta.html";
    } catch (err) {
        alert("Erro: " + err.message);
    }
}
