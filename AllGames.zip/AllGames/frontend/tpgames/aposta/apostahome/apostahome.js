function backHome() {
    window.location.href = "../../tpgames.html";
}