function voltar() {
    window.location.href = "../fourline-dificuldade.html";
}

let timer = 0;
let interval;

function mostrarPreview(cor, colunaIndex) {
    const slots = document.querySelectorAll(".hover-slot");
    slots.forEach((slot, i) => {
        slot.innerHTML = ""; // remove qualquer peça anterior
        if (i === colunaIndex) {
            const preview = document.createElement("div");
            preview.classList.add("preview-piece", cor === "vermelho" ? "red" : "blue");
            slot.appendChild(preview);
        }
    });
}

function limparPreview() {
    document.querySelectorAll(".hover-slot").forEach(slot => {
        slot.innerHTML = "";
    });
}


window.addEventListener("DOMContentLoaded", () => {
    userId = localStorage.getItem("userId");
    dificuldade = localStorage.getItem("nivelSelecionado") || "facil";
    document.getElementById("nivelDificuldade").innerText = "Dificuldade: Amigo";
    startTimer();
    document.querySelector(".currentPlayer").innerText = "Vez: Vermelho";


    const hoverSlots = document.querySelectorAll('.hover-slot');

    document.querySelectorAll('.coluna').forEach((coluna, index) => {
        coluna.addEventListener('mouseenter', () => {
            const cor = turn % 2 !== 0 ? "vermelho" : "azul";
            mostrarPreview(cor, index);
        });
        coluna.addEventListener('mouseleave', () => {
            limparPreview();
        });

    });

});

function startTimer() {
    interval = setInterval(() => {
        timer++;
        const min = String(Math.floor(timer / 60)).padStart(2, '0');
        const sec = String(timer % 60).padStart(2, '0');
        document.getElementById("timer").innerText = `${min}:${sec}`;
    }, 1000);
}

function stopTimer() {
    clearInterval(interval);
}

let val_c1 = 1, val_c2 = 1, val_c3 = 1, val_c4 = 1, val_c5 = 1, val_c6 = 1, val_c7 = 1;
let turn = 1;

function corParaNome(cor) {
    const cores = {
        'rgb(255, 0, 0)': 'vermelho',
        'rgb(0, 102, 255)': 'azul'
    };
    return cores[cor] || cor;
}


function check(playerColor) {
    setTimeout(() => {
        for (let i = 1; i <= 7; i++) {
            for (let j = 1; j <= 3; j++) {
                if (
                    getCor(`c${i}r${j}`) === playerColor &&
                    getCor(`c${i}r${j + 1}`) === playerColor &&
                    getCor(`c${i}r${j + 2}`) === playerColor &&
                    getCor(`c${i}r${j + 3}`) === playerColor
                ) {
                    alert(`Parabéns! O jogador ${corParaNome(playerColor)} venceu!`);
                    location.reload();
                    return;
                }
            }
        }

        for (let i = 1; i <= 6; i++) {
            for (let j = 1; j <= 4; j++) {
                if (
                    getCor(`c${j}r${i}`) === playerColor &&
                    getCor(`c${j + 1}r${i}`) === playerColor &&
                    getCor(`c${j + 2}r${i}`) === playerColor &&
                    getCor(`c${j + 3}r${i}`) === playerColor
                ) {
                    alert(`Parabéns! O jogador ${corParaNome(playerColor)} venceu!`);
                    location.reload();
                    return;
                }
            }
        }

        for (let i = 1; i <= 4; i++) {
            for (let j = 1; j <= 3; j++) {
                if (
                    getCor(`c${i}r${j}`) === playerColor &&
                    getCor(`c${i + 1}r${j + 1}`) === playerColor &&
                    getCor(`c${i + 2}r${j + 2}`) === playerColor &&
                    getCor(`c${i + 3}r${j + 3}`) === playerColor
                ) {
                    alert(`Parabéns! O jogador ${corParaNome(playerColor)} venceu!`);
                    location.reload();
                    return;
                }
            }
        }

        for (let i = 1; i <= 4; i++) {
            for (let j = 6; j >= 4; j--) {
                if (
                    getCor(`c${i}r${j}`) === playerColor &&
                    getCor(`c${i + 1}r${j - 1}`) === playerColor &&
                    getCor(`c${i + 2}r${j - 2}`) === playerColor &&
                    getCor(`c${i + 3}r${j - 3}`) === playerColor
                ) {
                    alert(`Parabéns! O jogador ${corParaNome(playerColor)} venceu!`);
                    location.reload();
                    return;
                }
            }
        }
    }, 200);
}

function getCor(id) {
    return document.getElementById(id).style.backgroundColor;
}

// Jogar
document.querySelectorAll(".coluna").forEach((e) => {
    e.addEventListener("click", () => {
        let sum = eval(`val_${e.id}`);
        eval(`val_${e.id}++`);

        if (sum <= 6 && turn % 2 !== 0) {
            document.getElementById(`${e.id}r${sum}`).style.backgroundColor = "#ff0000";
            turn++;
            check("rgb(255, 0, 0)");
            document.querySelector(".currentPlayer").innerText = "Vez: Azul";
        } else if (sum <= 6 && turn % 2 === 0) {
            document.getElementById(`${e.id}r${sum}`).style.backgroundColor = "#0066ff";
            turn++;
            check("rgb(0, 102, 255)");
            document.querySelector(".currentPlayer").innerText = "Vez: Vermelho";
        }
    });
});
