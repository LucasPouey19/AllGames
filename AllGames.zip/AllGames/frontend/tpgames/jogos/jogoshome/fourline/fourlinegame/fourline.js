function voltar() {
    window.location.href = "../velha-dificuldade.html";
}

let timer = 0;
let playerSymbol = "X"; // Padrão é X
let botSymbol = "O";
let isPlayerTurn = true;
let gameActive = true;
let symbolChosen = false;

window.addEventListener("DOMContentLoaded", () => {
    userId = localStorage.getItem("userId");
    dificuldade = localStorage.getItem("nivelSelecionado") || "facil";
    document.getElementById("nivelDificuldade").innerText = "Dificuldade: " + dificuldade.charAt(0).toUpperCase() + dificuldade.slice(1);
    startTimer();

    // Mostra a seleção de símbolo apenas se não tiver sido escolhido ainda
    if (!symbolChosen) {
        document.getElementById("symbolSelection").style.display = "block";

        // Configura os botões de seleção de símbolo
        document.getElementById("choose-x").addEventListener("click", () => {
            setPlayerSymbol("X");
        });

        document.getElementById("choose-o").addEventListener("click", () => {
            setPlayerSymbol("O");
        });
    } else {
        document.getElementById("symbolSelection").style.display = "none";
    }
});

function setPlayerSymbol(symbol) {
    playerSymbol = symbol;
    botSymbol = symbol === "X" ? "O" : "X";
    symbolChosen = true;

    // Esconde a seleção de símbolo após a escolha
    document.getElementById("symbolSelection").style.display = "none";

    // Atualiza a aparência dos botões
    document.getElementById("choose-x").classList.toggle("active", symbol === "X");
    document.getElementById("choose-o").classList.toggle("active", symbol === "O");

    // Reinicia o jogo com o novo símbolo
    init();
}

function startTimer() {
    interval = setInterval(() => {
        timer++;
        const min = String(Math.floor(timer / 60)).padStart(2, '0');
        const sec = String(timer % 60).padStart(2, '0');
        document.getElementById("timer").innerText = `${min}:${sec}`;
    }, 1000);
}

function stopTimer() {
    clearInterval(interval);
}

const currentPlayer = document.querySelector(".currentPlayer");

let selected;
let player = "X"; // Isso será sobrescrito pelo playerSymbol

let positions = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [1, 4, 7],
    [2, 5, 8],
    [3, 6, 9],
    [1, 5, 9],
    [3, 5, 7],
];

function init() {
    // Se o símbolo não foi escolhido, não inicia o jogo
    if (!symbolChosen) return;

    gameActive = true;
    selected = [];
    isPlayerTurn = playerSymbol === "X"; // X sempre começa

    currentPlayer.innerHTML = `Jogador da vez: ${isPlayerTurn ? "Você (" + playerSymbol + ")" : "Bot (" + botSymbol + ")"}`;
    document.getElementById("turno-display").innerText = `Vez: ${isPlayerTurn ? "Você" : "Bot"}`;

    document.querySelectorAll(".game button").forEach((item) => {
        item.innerHTML = "";
        item.addEventListener("click", newMove);
        item.disabled = false;
    });

    // Se for a vez do bot, faz a jogada
    if (!isPlayerTurn) {
        setTimeout(botMove, 500);
    }
}

function newMove(e) {
    if (!isPlayerTurn || !gameActive) return;

    const index = e.target.getAttribute("data-i");
    e.target.innerHTML = playerSymbol;
    e.target.disabled = true;
    selected[index] = playerSymbol;

    setTimeout(() => {
        check();
    }, 100);

    isPlayerTurn = false;
    currentPlayer.innerHTML = `Jogador da vez: Bot (${botSymbol})`;
    document.getElementById("turno-display").innerText = "Vez: Bot";

    // Se o jogo ainda estiver ativo, o bot faz sua jogada
    if (gameActive) {
        setTimeout(botMove, 800);
    }
}

function botMove() {
    if (isPlayerTurn || !gameActive) return;

    let move;
    switch (dificuldade) {
        case "facil":
            move = getRandomMove();
            break;
        case "medio":
            move = getIntermediateMove();
            break;
        case "dificil":
            move = getBestMove();
            break;
        default:
            move = getRandomMove();
    }

    if (move !== -1) {
        const button = document.querySelector(`button[data-i="${move}"]`);
        button.innerHTML = botSymbol;
        button.disabled = true;
        selected[move] = botSymbol;

        setTimeout(() => {
            check();
        }, 100);
    }

    isPlayerTurn = true;
    currentPlayer.innerHTML = `Jogador da vez: Você (${playerSymbol})`;
    document.getElementById("turno-display").innerText = "Vez: Você";
}

// Funções de IA para o bot
function getRandomMove() {
    const emptyCells = [];
    for (let i = 1; i <= 9; i++) {
        if (!selected[i]) emptyCells.push(i);
    }
    return emptyCells.length > 0 ? emptyCells[Math.floor(Math.random() * emptyCells.length)] : -1;
}

function getIntermediateMove() {
    // 1. Verifica se pode ganhar
    for (let pos of positions) {
        const [a, b, c] = pos;
        if (selected[a] === botSymbol && selected[b] === botSymbol && !selected[c]) return c;
        if (selected[a] === botSymbol && !selected[b] && selected[c] === botSymbol) return b;
        if (!selected[a] && selected[b] === botSymbol && selected[c] === botSymbol) return a;
    }

    // 2. Bloqueia o jogador
    for (let pos of positions) {
        const [a, b, c] = pos;
        if (selected[a] === playerSymbol && selected[b] === playerSymbol && !selected[c]) return c;
        if (selected[a] === playerSymbol && !selected[b] && selected[c] === playerSymbol) return b;
        if (!selected[a] && selected[b] === playerSymbol && selected[c] === playerSymbol) return a;
    }

    // 3. Tenta pegar o centro
    if (!selected[5]) return 5;

    // 4. Movimento aleatório
    return getRandomMove();
}

function getBestMove() {
    // Implementação do algoritmo Minimax otimizado
    const board = { ...selected };

    // Se for o primeiro movimento do bot, retorna uma posição ótima
    const emptyCellsCount = 9 - Object.keys(board).length;
    if (emptyCellsCount === 9) {
        return 5; // Sempre começa no centro se possível (melhor estratégia)
    }
    if (emptyCellsCount === 8) {
        // Se o jogador não escolheu o centro, pega o centro
        if (!board[5]) return 5;
        // Se o jogador escolheu o centro, pega um canto (melhor resposta)
        const corners = [1, 3, 7, 9];
        return corners[Math.floor(Math.random() * corners.length)];
    }

    // Função de avaliação do Minimax
    function minimax(board, depth, isMaximizing, alpha = -Infinity, beta = Infinity) {
        // Verifica se o jogo terminou
        const winner = checkWinner(board);
        if (winner === botSymbol) return 10 - depth;
        if (winner === playerSymbol) return depth - 10;
        if (Object.keys(board).length === 9) return 0;

        if (isMaximizing) {
            let bestScore = -Infinity;
            for (let i = 1; i <= 9; i++) {
                if (!board[i]) {
                    board[i] = botSymbol;
                    const score = minimax(board, depth + 1, false, alpha, beta);
                    board[i] = null;
                    bestScore = Math.max(score, bestScore);
                    alpha = Math.max(alpha, score);
                    if (beta <= alpha) break; // Poda alfa-beta
                }
            }
            return bestScore;
        } else {
            let bestScore = Infinity;
            for (let i = 1; i <= 9; i++) {
                if (!board[i]) {
                    board[i] = playerSymbol;
                    const score = minimax(board, depth + 1, true, alpha, beta);
                    board[i] = null;
                    bestScore = Math.min(score, bestScore);
                    beta = Math.min(beta, score);
                    if (beta <= alpha) break; // Poda alfa-beta
                }
            }
            return bestScore;
        }
    }

    let bestScore = -Infinity;
    let bestMoves = [];

    // Avalia todos os movimentos possíveis
    for (let i = 1; i <= 9; i++) {
        if (!board[i]) {
            board[i] = botSymbol;
            const score = minimax(board, 0, false);
            board[i] = null;

            if (score > bestScore) {
                bestScore = score;
                bestMoves = [i];
            } else if (score === bestScore) {
                bestMoves.push(i);
            }
        }
    }

    // Escolhe aleatoriamente entre os melhores movimentos (para variar um pouco)
    return bestMoves.length > 0
        ? bestMoves[Math.floor(Math.random() * bestMoves.length)]
        : getRandomMove();
}

function checkWinner(board) {
    // Verifica todas as possíveis combinações vencedoras
    for (let [a, b, c] of positions) {
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            return board[a];
        }
    }
    return null;
}


function check() {
    const winner = checkWinner(selected);
    let pontos = 0
    let mensagem = '';

    if (winner) {
        gameActive = false;
        if (winner === playerSymbol) {
            alert("Você ganhou!");
            if (dificuldade === "facil") {
                pontos = 1;
                console.log("Dados enviados:", { userId, dificuldade, pontos })

            } if (dificuldade === "media") {
                pontos = 2
                console.log("Dados enviados:", { userId, dificuldade, pontos })

            } if (dificuldade === "dificil") {
                pontos = 3
                console.log("Dados enviados:", { userId, dificuldade, pontos })

            }
        } else {
            alert("O bot ganhou!");
            pontos = -1
            console.log("Dados enviados:", { userId, dificuldade, pontos })
        }


        fetch("http://localhost:3005/velha/score", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userId, dificuldade, pontos }),
        })
            .then((res) => res.json())
            .then((data) => {
                console.log("Resposta do servidor:", data);
                const confirmarSaida = confirm(`${mensagem}Deseja voltar para a página de jogos?`);
                if (confirmarSaida) {
                    window.location.href = "../../jogoshome.html";
                }
            })
            .catch((err) => {
                console.error("Erro ao salvar pontuação:", err);
                alert("Erro ao registrar pontuação. Tente novamente mais tarde.");
            });
        init();
        return;
    }

    // Verifica empate
    let isDraw = true;
    for (let i = 1; i <= 9; i++) {
        if (!selected[i]) {
            isDraw = false;
            break;
        }
    }

    if (isDraw) {
        gameActive = false;
        alert("DEU EMPATE!");
        init();
    }
}