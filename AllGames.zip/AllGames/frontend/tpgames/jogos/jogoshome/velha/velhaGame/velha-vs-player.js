function voltar() {
    window.location.href = "../velha-dificuldade.html";
}

let timer = 0;

window.addEventListener("DOMContentLoaded", () => {
    userId = localStorage.getItem("userId")
    dificuldade = localStorage.getItem("nivelSelecionado") || "facil";
    document.getElementById("nivelDificuldade").innerText = "Dificuldade: Amigo";
    startTimer();
});

function startTimer() {
    interval = setInterval(() => {
        timer++;
        const min = String(Math.floor(timer / 60)).padStart(2, '0');
        const sec = String(timer % 60).padStart(2, '0');
        document.getElementById("timer").innerText = `${min}:${sec}`;
    }, 1000);
}

function stopTimer() {
    clearInterval(interval);
}

const currentPlayer = document.querySelector(".currentPlayer");

let selected;
let player = "X";

let positions = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [1, 4, 7],
    [2, 5, 8],
    [3, 6, 9],
    [1, 5, 9],
    [3, 5, 7],
];

function init() {
    selected = [];

    currentPlayer.innerHTML = `Jogador da vez: ${player}`;

    document.querySelectorAll(".game button").forEach((item) => {
        item.innerHTML = "";
        item.addEventListener("click", newMove)
    })
}

init();

function newMove(e) {
    const index = e.target.getAttribute("data-i");
    e.target.innerHTML = player;
    e.target.removeEventListener("click", newMove);
    selected[index] = player;

    setTimeout(() => {
        check();
    }, [100]);

    player = player === "X" ? "O" : "X";
    currentPlayer.innerHTML = `JOGADOR DA VEZ: ${player}`;
}

function check() {
    let playerLastMove = player === "X" ? "O" : "X";

    const items = selected
        .map((item, i) => [item, i])
        .filter((item) => item[0] === playerLastMove)
        .map((item) => item[1]);

    for (pos of positions) {
        if (pos.every((item) => items.includes(item))) {
            alert("O JOGADOR '" + playerLastMove + "' GANHOU!");
            window.location.href = "../velha-dificuldade.html";
            return;
        }
    }

    if (selected.filter((item) => item).length === 9) {
        alert("DEU EMPATE!");
        window.location.href = "../velha-dificuldade.html";
        return;
    }
}