function voltar() {
    window.location.href = "../xadrez-dificuldade.html";
}

const pieceSymbols = {
    w: {
        P: "https://upload.wikimedia.org/wikipedia/commons/4/45/Chess_plt45.svg",
        R: "https://upload.wikimedia.org/wikipedia/commons/7/72/Chess_rlt45.svg",
        N: "https://upload.wikimedia.org/wikipedia/commons/7/70/Chess_nlt45.svg",
        B: "https://upload.wikimedia.org/wikipedia/commons/b/b1/Chess_blt45.svg",
        Q: "https://upload.wikimedia.org/wikipedia/commons/1/15/Chess_qlt45.svg",
        K: "https://upload.wikimedia.org/wikipedia/commons/4/42/Chess_klt45.svg"
    },
    b: {
        P: "https://upload.wikimedia.org/wikipedia/commons/c/c7/Chess_pdt45.svg",
        R: "https://upload.wikimedia.org/wikipedia/commons/f/ff/Chess_rdt45.svg",
        N: "https://upload.wikimedia.org/wikipedia/commons/e/ef/Chess_ndt45.svg",
        B: "https://upload.wikimedia.org/wikipedia/commons/9/98/Chess_bdt45.svg",
        Q: "https://upload.wikimedia.org/wikipedia/commons/4/47/Chess_qdt45.svg",
        K: "https://upload.wikimedia.org/wikipedia/commons/f/f0/Chess_kdt45.svg"
    }
};

let boardState = [];
let selectedPiece = null;
let selectedX = null;
let selectedY = null;
let timer = 0;
let interval = null;
let turno = 'branco'; // 'branco' ou 'preto'
let jogoAcabou = false;

// Função para atualizar o display de turno
function atualizarTurnoDisplay() {
    const turnoDisplay = document.getElementById("turno-display");
    turnoDisplay.textContent = `Vez: ${turno === 'branco' ? 'Brancas' : 'Pretas'}`;
    turnoDisplay.style.backgroundColor = turno === 'branco' ? '#f0f0f0' : '#333';
    turnoDisplay.style.color = turno === 'branco' ? '#333' : '#f0f0f0';
}

window.addEventListener("DOMContentLoaded", () => {
    document.getElementById("nivelDificuldade").innerText = "Dificuldade: Amigo";
    initializeBoard();
    createBoard();
    startTimer();
    atualizarTurnoDisplay();
});

function startTimer() {
    interval = setInterval(() => {
        timer++;
        const min = String(Math.floor(timer / 60)).padStart(2, '0');
        const sec = String(timer % 60).padStart(2, '0');
        document.getElementById("timer").innerText = `${min}:${sec}`;
    }, 1000);
}

function stopTimer() {
    clearInterval(interval);
}

function endGame(resultado) {
    stopTimer();
    jogoAcabou = true;

    let mensagem = "";
    if (resultado === "branco") {
        mensagem = "Xeque-mate! As brancas venceram!";
    } else if (resultado === "preto") {
        mensagem = "Xeque-mate! As pretas venceram!";
    } else {
        mensagem = "Empate!";
    }

    alert(mensagem);
}

function initializeBoard() {
    boardState = [
        [{ type: 'R', color: 'b' }, { type: 'N', color: 'b' }, { type: 'B', color: 'b' }, { type: 'Q', color: 'b' }, { type: 'K', color: 'b' }, { type: 'B', color: 'b' }, { type: 'N', color: 'b' }, { type: 'R', color: 'b' }],
        Array(8).fill({ type: 'P', color: 'b' }),
        Array(8).fill(null),
        Array(8).fill(null),
        Array(8).fill(null),
        Array(8).fill(null),
        Array(8).fill({ type: 'P', color: 'w' }),
        [{ type: 'R', color: 'w' }, { type: 'N', color: 'w' }, { type: 'B', color: 'w' }, { type: 'Q', color: 'w' }, { type: 'K', color: 'w' }, { type: 'B', color: 'w' }, { type: 'N', color: 'w' }, { type: 'R', color: 'w' }]
    ];
}

function createBoard() {
    const board = document.getElementById("chessboard");
    board.innerHTML = "";
    for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
            const square = document.createElement("div");
            square.classList.add("square", (x + y) % 2 === 0 ? "white" : "black");
            square.dataset.x = x;
            square.dataset.y = y;

            const piece = boardState[y][x];
            if (piece) {
                const pieceEl = document.createElement("img");
                pieceEl.src = pieceSymbols[piece.color][piece.type];
                pieceEl.classList.add("piece-img", "piece", piece.color === "w" ? "white-piece" : "black-piece");
                pieceEl.draggable = false;
                square.appendChild(pieceEl);
            }

            square.addEventListener("click", handleSquareClick);
            board.appendChild(square);
        }
    }
}

function handleSquareClick(e) {
    if (jogoAcabou) return;

    const x = parseInt(e.currentTarget.dataset.x);
    const y = parseInt(e.currentTarget.dataset.y);
    const piece = boardState[y][x];

    clearHighlights();

    if (selectedPiece) {
        // Verifica se é a vez do jogador correto
        const jogadorAtual = turno === 'branco' ? 'w' : 'b';
        if (selectedPiece.color !== jogadorAtual) {
            selectedPiece = null;
            createBoard();
            return;
        }

        if (isValidMove(selectedPiece, selectedX, selectedY, x, y)) {
            const pecaCapturada = boardState[y][x];

            // Faz a jogada
            boardState[y][x] = selectedPiece;
            boardState[selectedY][selectedX] = null;

            // Verifica promoção de peão
            if (selectedPiece.type === 'P' && (y === 0 || y === 7)) {
                boardState[y][x] = { type: 'Q', color: selectedPiece.color };
            }

            selectedPiece = null;
            createBoard();

            // Verifica se capturou o rei
            if (pecaCapturada?.type === 'K') {
                endGame(turno);
                return;
            }

            // Verifica xeque e xeque-mate para o oponente
            const oponente = turno === 'branco' ? 'preto' : 'branco';
            const corOponente = turno === 'branco' ? 'b' : 'w';

            if (isInCheck(corOponente)) {
                if (isCheckmate(corOponente)) {
                    setTimeout(() => {
                        endGame(turno);
                    }, 100);
                    return;
                } else {
                    setTimeout(() => {
                        alert(`Xeque nas ${oponente === 'branco' ? 'brancas' : 'pretas'}!`);
                    }, 100);
                }
            }

            // Alterna o turno
            turno = oponente;
            atualizarTurnoDisplay();
        } else {
            selectedPiece = null;
            createBoard();
        }
    } else if (piece) {
        // Verifica se é a peça do jogador atual
        const jogadorAtual = turno === 'branco' ? 'w' : 'b';
        if (piece.color === jogadorAtual) {
            selectedPiece = piece;
            selectedX = x;
            selectedY = y;
            highlightMoves(piece, x, y);
        }
    }
}

function highlightMoves(piece, x, y) {
    document.querySelector(`[data-x="${x}"][data-y="${y}"]`).classList.add("selected");
    for (let j = 0; j < 8; j++) {
        for (let i = 0; i < 8; i++) {
            if (isValidMove(piece, x, y, i, j)) {
                const square = document.querySelector(`[data-x="${i}"][data-y="${j}"]`);
                const dot = document.createElement("div");
                dot.classList.add("dot");
                square.appendChild(dot);
            }
        }
    }
}

function clearHighlights() {
    document.querySelectorAll(".dot").forEach(dot => dot.remove());
    document.querySelectorAll(".selected").forEach(el => el.classList.remove("selected"));
}

function isInCheck(color) {
    const kingPos = findKing(color);
    if (!kingPos) return false;

    const opponent = color === 'w' ? 'b' : 'w';

    for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
            const piece = boardState[y][x];
            if (piece && piece.color === opponent) {
                if (isValidMove(piece, x, y, kingPos.x, kingPos.y)) {
                    return true;
                }
            }
        }
    }
    return false;
}

function isCheckmate(color) {
    if (!isInCheck(color)) return false;

    const moves = getAllValidMoves(color);
    for (const m of moves) {
        const backup = JSON.parse(JSON.stringify(boardState));

        // Faz o movimento temporariamente
        boardState[m.destino.y][m.destino.x] = m.peca;
        boardState[m.origem.y][m.origem.x] = null;

        const aindaEmXeque = isInCheck(color);

        // Desfaz o movimento
        boardState = backup;

        if (!aindaEmXeque) {
            return false;
        }
    }
    return true;
}

function isSquareAttacked(x, y, byColor) {
    for (let j = 0; j < 8; j++) {
        for (let i = 0; i < 8; i++) {
            const piece = boardState[j][i];
            if (piece && piece.color === byColor) {
                if (isValidMove(piece, i, j, x, y)) {
                    return true;
                }
            }
        }
    }
    return false;
}

function getAllValidMoves(cor) {
    const moves = [];
    for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
            const p = boardState[y][x];
            if (p && p.color === cor) {
                for (let j = 0; j < 8; j++) {
                    for (let i = 0; i < 8; i++) {
                        if (isValidMove(p, x, y, i, j)) {
                            moves.push({
                                peca: p,
                                origem: { x, y },
                                destino: { x: i, y: j },
                                captura: boardState[j][i]
                            });
                        }
                    }
                }
            }
        }
    }
    return moves;
}

function isValidMove(piece, fromX, fromY, toX, toY) {
    const dx = toX - fromX;
    const dy = toY - fromY;
    const target = boardState[toY][toX];

    // Não pode capturar peça da mesma cor
    if (target && target.color === piece.color) return false;

    switch (piece.type) {
        case 'P': // Peão
            const dir = piece.color === 'w' ? -1 : 1;
            const startRow = piece.color === 'w' ? 6 : 1;

            // Movimento para frente
            if (dx === 0 && !target) {
                // Movimento simples
                if (dy === dir) return true;
                // Movimento duplo inicial
                if (fromY === startRow && dy === 2 * dir && !boardState[fromY + dir][fromX]) {
                    return true;
                }
            }
            // Captura
            if (Math.abs(dx) === 1 && dy === dir && target) {
                return true;
            }
            return false;

        case 'R': // Torre
            return (dx === 0 || dy === 0) && isClearStraightLine(fromX, fromY, toX, toY);

        case 'N': // Cavalo
            return (Math.abs(dx) === 2 && Math.abs(dy) === 1) || (Math.abs(dx) === 1 && Math.abs(dy) === 2);

        case 'B': // Bispo
            return Math.abs(dx) === Math.abs(dy) && isClearDiagonal(fromX, fromY, toX, toY);

        case 'Q': // Rainha
            return ((dx === 0 || dy === 0) && isClearStraightLine(fromX, fromY, toX, toY)) ||
                (Math.abs(dx) === Math.abs(dy) && isClearDiagonal(fromX, fromY, toX, toY));

        case 'K': // Rei
            return Math.abs(dx) <= 1 && Math.abs(dy) <= 1;

        default:
            return false;
    }
}

function isClearStraightLine(x1, y1, x2, y2) {
    if (x1 !== x2 && y1 !== y2) return false;
    const dx = x2 === x1 ? 0 : (x2 > x1 ? 1 : -1);
    const dy = y2 === y1 ? 0 : (y2 > y1 ? 1 : -1);
    let x = x1 + dx, y = y1 + dy;
    while (x !== x2 || y !== y2) {
        if (boardState[y][x]) return false;
        x += dx;
        y += dy;
    }
    return true;
}

function isClearDiagonal(x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    if (Math.abs(dx) !== Math.abs(dy)) return false;
    const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1;
    let x = x1 + stepX, y = y1 + stepY;
    while (x !== x2 && y !== y2) {
        if (boardState[y][x]) return false;
        x += stepX;
        y += stepY;
    }
    return true;
}

function findKing(color) {
    for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
            const p = boardState[y][x];
            if (p && p.color === color && p.type === 'K') return { x, y };
        }
    }
    return null;
}