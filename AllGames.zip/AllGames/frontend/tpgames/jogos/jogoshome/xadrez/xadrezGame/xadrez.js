function voltar() {
    window.location.href = "../xadrez-dificuldade.html";
}

const pieceSymbols = {
    w: {
        P: "https://upload.wikimedia.org/wikipedia/commons/4/45/Chess_plt45.svg",
        R: "https://upload.wikimedia.org/wikipedia/commons/7/72/Chess_rlt45.svg",
        N: "https://upload.wikimedia.org/wikipedia/commons/7/70/Chess_nlt45.svg",
        B: "https://upload.wikimedia.org/wikipedia/commons/b/b1/Chess_blt45.svg",
        Q: "https://upload.wikimedia.org/wikipedia/commons/1/15/Chess_qlt45.svg",
        K: "https://upload.wikimedia.org/wikipedia/commons/4/42/Chess_klt45.svg"
    },
    b: {
        P: "https://upload.wikimedia.org/wikipedia/commons/c/c7/Chess_pdt45.svg",
        R: "https://upload.wikimedia.org/wikipedia/commons/f/ff/Chess_rdt45.svg",
        N: "https://upload.wikimedia.org/wikipedia/commons/e/ef/Chess_ndt45.svg",
        B: "https://upload.wikimedia.org/wikipedia/commons/9/98/Chess_bdt45.svg",
        Q: "https://upload.wikimedia.org/wikipedia/commons/4/47/Chess_qdt45.svg",
        K: "https://upload.wikimedia.org/wikipedia/commons/f/f0/Chess_kdt45.svg"
    }
};

let boardState = [];
let selectedPiece = null;
let selectedX = null;
let selectedY = null;
let timer = 0;
let interval = null;
let dificuldade = "facil";
let turno = 'branco';
let jogoAcabou = false;

// Função para atualizar o display de turno
function atualizarTurnoDisplay() {
    const turnoDisplay = document.getElementById("turno-display");
    turnoDisplay.textContent = `Vez: ${turno === 'branco' ? 'Brancas' : 'Pretas'}`;
    turnoDisplay.style.backgroundColor = turno === 'branco' ? '#f0f0f0' : '#333';
    turnoDisplay.style.color = turno === 'branco' ? '#333' : '#f0f0f0';
}

window.addEventListener("DOMContentLoaded", () => {
    userId = localStorage.getItem("userId")
    dificuldade = localStorage.getItem("nivelSelecionado") || "facil";
    document.getElementById("nivelDificuldade").innerText = "Dificuldade: " + dificuldade.charAt(0).toUpperCase() + dificuldade.slice(1);
    initializeBoard();
    createBoard();
    startTimer();
    atualizarTurnoDisplay();
});

function startTimer() {
    interval = setInterval(() => {
        timer++;
        const min = String(Math.floor(timer / 60)).padStart(2, '0');
        const sec = String(timer % 60).padStart(2, '0');
        document.getElementById("timer").innerText = `${min}:${sec}`;
    }, 1000);
}

function stopTimer() {
    clearInterval(interval);
}

function endGame(resultado) {
    stopTimer();
    jogoAcabou = true;

    let mensagem = "";
    let pontos = 0;

    // Determina os pontos com base no resultado e dificuldade
    switch (resultado) {
        case "player":
            pontos = dificuldade === 'facil' ? 1 : dificuldade === 'medio' ? 2 : 3;
            mensagem = `Parabéns! Você venceu! +${pontos} ponto(s).`;
            break;
        case "bot":
            pontos = -1;
            mensagem = "Que azar! Você perdeu! -1 ponto.";
            break;
        case "draw":
            pontos = 0;
            mensagem = "Empate! Nenhum ponto alterado.";
            break;
    }
    console.log("Dados enviados:", { userId, dificuldade, pontos });

    // Atualiza o backend com os pontos corretos
    fetch("http://localhost:3005/chess/score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, dificuldade, pontos }),
    })
        .then((res) => res.json())
        .then((data) => {
            console.log("Resposta do servidor:", data);
            const confirmarSaida = confirm(`${mensagem}\nDeseja voltar para a página de jogos?`);
            if (confirmarSaida) {
                window.location.href = "../../jogoshome.html";
            }
        })
        .catch((err) => {
            console.error("Erro ao salvar pontuação:", err);
            alert("Erro ao registrar pontuação. Tente novamente mais tarde.");
        });

}

function initializeBoard() {
    boardState = [
        [{ type: 'R', color: 'b' }, { type: 'N', color: 'b' }, { type: 'B', color: 'b' }, { type: 'Q', color: 'b' }, { type: 'K', color: 'b' }, { type: 'B', color: 'b' }, { type: 'N', color: 'b' }, { type: 'R', color: 'b' }],
        Array(8).fill({ type: 'P', color: 'b' }),
        Array(8).fill(null),
        Array(8).fill(null),
        Array(8).fill(null),
        Array(8).fill(null),
        Array(8).fill({ type: 'P', color: 'w' }),
        [{ type: 'R', color: 'w' }, { type: 'N', color: 'w' }, { type: 'B', color: 'w' }, { type: 'Q', color: 'w' }, { type: 'K', color: 'w' }, { type: 'B', color: 'w' }, { type: 'N', color: 'w' }, { type: 'R', color: 'w' }]
    ];
}

function createBoard() {
    const board = document.getElementById("chessboard");
    board.innerHTML = "";
    for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
            const square = document.createElement("div");
            square.classList.add("square", (x + y) % 2 === 0 ? "white" : "black");
            square.dataset.x = x;
            square.dataset.y = y;

            const piece = boardState[y][x];
            if (piece) {
                const pieceEl = document.createElement("img");
                pieceEl.src = pieceSymbols[piece.color][piece.type];
                pieceEl.classList.add("piece-img", "piece", piece.color === "w" ? "white-piece" : "black-piece");
                pieceEl.draggable = false;
                square.appendChild(pieceEl);
            }

            square.addEventListener("click", handleSquareClick);
            board.appendChild(square);
        }
    }
}

function handleSquareClick(e) {
    if (jogoAcabou || turno !== 'branco') return;

    const x = parseInt(e.currentTarget.dataset.x);
    const y = parseInt(e.currentTarget.dataset.y);
    const piece = boardState[y][x];

    clearHighlights();

    if (selectedPiece) {
        if (isValidMove(selectedPiece, selectedX, selectedY, x, y)) {
            const pecaCapturada = boardState[y][x];

            // Faz a jogada
            boardState[y][x] = selectedPiece;
            boardState[selectedY][selectedX] = null;

            // Verifica promoção de peão
            if (selectedPiece.type === 'P' && (y === 0 || y === 7)) {
                boardState[y][x] = { type: 'Q', color: selectedPiece.color };
            }

            selectedPiece = null;
            createBoard();

            if (pecaCapturada?.type === 'K') {
                endGame("player");
                return;
            }

            if (isInCheck('b')) {
                if (isCheckmate('b')) {
                    setTimeout(() => {
                        alert("Xeque-mate! Você venceu!");
                        endGame("player");
                    }, 100);
                    return;
                } else {
                    setTimeout(() => {
                        alert("Xeque nas pretas!");
                    }, 100);
                }
            }

            turno = 'preto';
            atualizarTurnoDisplay();
            setTimeout(botJogar, 500);
        } else {
            selectedPiece = null;
            createBoard();
        }
    } else if (piece && piece.color === 'w') {
        selectedPiece = piece;
        selectedX = x;
        selectedY = y;
        highlightMoves(piece, x, y);
    }
}

function highlightMoves(piece, x, y) {
    document.querySelector(`[data-x="${x}"][data-y="${y}"]`).classList.add("selected");
    for (let j = 0; j < 8; j++) {
        for (let i = 0; i < 8; i++) {
            if (isValidMove(piece, x, y, i, j)) {
                const square = document.querySelector(`[data-x="${i}"][data-y="${j}"]`);
                const dot = document.createElement("div");
                dot.classList.add("dot");
                square.appendChild(dot);
            }
        }
    }
}

function clearHighlights() {
    document.querySelectorAll(".dot").forEach(dot => dot.remove());
    document.querySelectorAll(".selected").forEach(el => el.classList.remove("selected"));
}

function botJogar() {
    if (jogoAcabou || turno !== 'preto') return;

    const movimentos = getAllValidMoves('b');
    if (!movimentos.length) {
        if (isInCheck('b')) {
            endGame("player"); // Xeque-mate
        } else {
            endGame("draw"); // Empate
        }
        return;
    }

    let jogada;

    if (dificuldade === 'facil') {
        // Bot fácil: faz jogadas aleatórias, mas evita perder peças sem necessidade
        const capturas = movimentos.filter(m => m.captura);
        const movimentosSeguros = movimentos.filter(m => {
            const backup = JSON.parse(JSON.stringify(boardState));
            boardState[m.destino.y][m.destino.x] = m.peca;
            boardState[m.origem.y][m.origem.x] = null;
            const ameacado = isSquareAttacked(m.destino.x, m.destino.y, 'w');
            boardState = backup;
            return !ameacado;
        });

        if (capturas.length > 0) {
            jogada = capturas[Math.floor(Math.random() * capturas.length)];
        } else if (movimentosSeguros.length > 0) {
            jogada = movimentosSeguros[Math.floor(Math.random() * movimentosSeguros.length)];
        } else {
            jogada = movimentos[Math.floor(Math.random() * movimentos.length)];
        }
    } else if (dificuldade === 'medio') {
        // Bot médio: estratégia básica com avaliação simples
        const valorPeca = { 'P': 1, 'N': 3, 'B': 3, 'R': 5, 'Q': 9, 'K': 0 };

        // Prioriza capturas, xeques e desenvolvimento
        const capturas = movimentos.filter(m => m.captura);
        const checks = movimentos.filter(m => {
            const backup = JSON.parse(JSON.stringify(boardState));
            boardState[m.destino.y][m.destino.x] = m.peca;
            boardState[m.origem.y][m.origem.x] = null;
            const result = isInCheck('w');
            boardState = backup;
            return result;
        });

        // Se houver xeque-mate, faz essa jogada
        const mateMoves = checks.filter(m => {
            const backup = JSON.parse(JSON.stringify(boardState));
            boardState[m.destino.y][m.destino.x] = m.peca;
            boardState[m.origem.y][m.origem.x] = null;
            const result = isCheckmate('w');
            boardState = backup;
            return result;
        });

        if (mateMoves.length > 0) {
            jogada = mateMoves[0];
        }
        // Se não, prioriza boas capturas
        else if (capturas.length > 0) {
            jogada = capturas.reduce((best, move) => {
                const valorAtual = valorPeca[best.captura?.type] || 0;
                const valorNovo = valorPeca[move.captura?.type] || 0;
                return valorNovo > valorAtual ? move : best;
            }, capturas[0]);
        }
        // Se não, faz xeque
        else if (checks.length > 0) {
            jogada = checks[Math.floor(Math.random() * checks.length)];
        }
        // Se não, desenvolve peças
        else {
            const movimentosDesenvolvimento = movimentos.filter(m => {
                // Centraliza peças
                const centroDist = Math.abs(m.destino.x - 3.5) + Math.abs(m.destino.y - 3.5);
                const centroAtual = Math.abs(m.origem.x - 3.5) + Math.abs(m.origem.y - 3.5);
                return centroDist < centroAtual;
            });

            jogada = movimentosDesenvolvimento.length > 0
                ? movimentosDesenvolvimento[Math.floor(Math.random() * movimentosDesenvolvimento.length)]
                : movimentos[Math.floor(Math.random() * movimentos.length)];
        }
    } else {
        // Bot difícil: avaliação de posição mais sofisticada
        const valorPeca = { 'P': 1, 'N': 3, 'B': 3, 'R': 5, 'Q': 9, 'K': 0 };
        let melhorJogada = null;
        let melhorValor = -Infinity;

        for (const movimento of movimentos) {
            const backup = JSON.parse(JSON.stringify(boardState));

            // Faz o movimento temporariamente
            boardState[movimento.destino.y][movimento.destino.x] = movimento.peca;
            boardState[movimento.origem.y][movimento.origem.x] = null;

            // Avalia a posição resultante
            let valor = 0;

            // 1. Valor material
            for (let y = 0; y < 8; y++) {
                for (let x = 0; x < 8; x++) {
                    const p = boardState[y][x];
                    if (p) {
                        valor += p.color === 'b' ? valorPeca[p.type] || 0 : -valorPeca[p.type] || 0;
                    }
                }
            }

            // 2. Bônus por capturas
            if (movimento.captura) {
                valor += valorPeca[movimento.captura.type] * 0.5;
            }

            // 3. Mobilidade
            valor += getAllValidMoves('b').length * 0.01;

            // 4. Segurança do rei
            const reiPos = findKing('b');
            if (isSquareAttacked(reiPos.x, reiPos.y, 'w')) {
                valor -= 0.5;
            }

            // 5. Xeque
            if (isInCheck('w')) {
                valor += 0.3;
            }

            // Se for melhor que a jogada atual, atualiza
            if (valor > melhorValor || (valor === melhorValor && Math.random() > 0.5)) {
                melhorValor = valor;
                melhorJogada = movimento;
            }

            // Desfaz o movimento
            boardState = backup;
        }

        jogada = melhorJogada || movimentos[0];
    }

    // Executa a jogada selecionada
    if (jogada) {
        const pecaCapturada = boardState[jogada.destino.y][jogada.destino.x];

        // Faz a jogada
        boardState[jogada.destino.y][jogada.destino.x] = jogada.peca;
        boardState[jogada.origem.y][jogada.origem.x] = null;

        // Verifica promoção de peão
        if (jogada.peca.type === 'P' && jogada.destino.y === 0) {
            boardState[jogada.destino.y][jogada.destino.x] = { type: 'Q', color: 'b' };
        }

        createBoard();

        // Verifica se capturou o rei
        if (pecaCapturada?.type === 'K') {
            endGame("bot");
            return;
        }

        // Verifica xeque e xeque-mate
        if (isInCheck('w')) {
            if (isCheckmate('w')) {
                setTimeout(() => {
                    alert("Xeque-mate! O bot venceu.");
                    endGame("bot");
                }, 100);
                return;
            } else {
                setTimeout(() => {
                    alert("Xeque nas brancas!");
                }, 100);
            }
        }

        turno = 'branco';
        atualizarTurnoDisplay();
    }
}

function isInCheck(color) {
    const kingPos = findKing(color);
    if (!kingPos) return false;

    const opponent = color === 'w' ? 'b' : 'w';

    for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
            const piece = boardState[y][x];
            if (piece && piece.color === opponent) {
                if (isValidMove(piece, x, y, kingPos.x, kingPos.y)) {
                    return true;
                }
            }
        }
    }
    return false;
}

function isCheckmate(color) {
    if (!isInCheck(color)) return false;

    const moves = getAllValidMoves(color);
    for (const m of moves) {
        const backup = JSON.parse(JSON.stringify(boardState));

        // Faz o movimento temporariamente
        boardState[m.destino.y][m.destino.x] = m.peca;
        boardState[m.origem.y][m.origem.x] = null;

        const aindaEmXeque = isInCheck(color);

        // Desfaz o movimento
        boardState = backup;

        if (!aindaEmXeque) {
            return false;
        }
    }
    return true;
}

function isSquareAttacked(x, y, byColor) {
    for (let j = 0; j < 8; j++) {
        for (let i = 0; i < 8; i++) {
            const piece = boardState[j][i];
            if (piece && piece.color === byColor) {
                if (isValidMove(piece, i, j, x, y)) {
                    return true;
                }
            }
        }
    }
    return false;
}

function getAllValidMoves(cor) {
    const moves = [];
    for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
            const p = boardState[y][x];
            if (p && p.color === cor) {
                for (let j = 0; j < 8; j++) {
                    for (let i = 0; i < 8; i++) {
                        if (isValidMove(p, x, y, i, j)) {
                            moves.push({
                                peca: p,
                                origem: { x, y },
                                destino: { x: i, y: j },
                                captura: boardState[j][i]
                            });
                        }
                    }
                }
            }
        }
    }
    return moves;
}

function isValidMove(piece, fromX, fromY, toX, toY) {
    const dx = toX - fromX;
    const dy = toY - fromY;
    const target = boardState[toY][toX];

    // Não pode capturar peça da mesma cor
    if (target && target.color === piece.color) return false;

    switch (piece.type) {
        case 'P': // Peão
            const dir = piece.color === 'w' ? -1 : 1;
            const startRow = piece.color === 'w' ? 6 : 1;

            // Movimento para frente
            if (dx === 0 && !target) {
                // Movimento simples
                if (dy === dir) return true;
                // Movimento duplo inicial
                if (fromY === startRow && dy === 2 * dir && !boardState[fromY + dir][fromX]) {
                    return true;
                }
            }
            // Captura
            if (Math.abs(dx) === 1 && dy === dir && target) {
                return true;
            }
            return false;

        case 'R': // Torre
            return (dx === 0 || dy === 0) && isClearStraightLine(fromX, fromY, toX, toY);

        case 'N': // Cavalo
            return (Math.abs(dx) === 2 && Math.abs(dy) === 1) || (Math.abs(dx) === 1 && Math.abs(dy) === 2);

        case 'B': // Bispo
            return Math.abs(dx) === Math.abs(dy) && isClearDiagonal(fromX, fromY, toX, toY);

        case 'Q': // Rainha
            return ((dx === 0 || dy === 0) && isClearStraightLine(fromX, fromY, toX, toY)) ||
                (Math.abs(dx) === Math.abs(dy) && isClearDiagonal(fromX, fromY, toX, toY));

        case 'K': // Rei
            return Math.abs(dx) <= 1 && Math.abs(dy) <= 1;

        default:
            return false;
    }
}

function isClearStraightLine(x1, y1, x2, y2) {
    if (x1 !== x2 && y1 !== y2) return false;
    const dx = x2 === x1 ? 0 : (x2 > x1 ? 1 : -1);
    const dy = y2 === y1 ? 0 : (y2 > y1 ? 1 : -1);
    let x = x1 + dx, y = y1 + dy;
    while (x !== x2 || y !== y2) {
        if (boardState[y][x]) return false;
        x += dx;
        y += dy;
    }
    return true;
}

function isClearDiagonal(x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    if (Math.abs(dx) !== Math.abs(dy)) return false;
    const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1;
    let x = x1 + stepX, y = y1 + stepY;
    while (x !== x2 && y !== y2) {
        if (boardState[y][x]) return false;
        x += stepX;
        y += stepY;
    }
    return true;
}

function findKing(color) {
    for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
            const p = boardState[y][x];
            if (p && p.color === color && p.type === 'K') return { x, y };
        }
    }
    return null;
}