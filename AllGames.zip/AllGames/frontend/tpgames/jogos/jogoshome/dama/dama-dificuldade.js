
function voltar() {
    window.location.href = "../jogoshome.html";
}

document.addEventListener("DOMContentLoaded", () => {
    atualizarLabel();
});

function atualizarLabel() {
    const selecionado = document.querySelector('input[name="radio"]:checked');
    const label = document.getElementById("labelDificuldade");

    if (selecionado.value === "1") label.textContent = "Fácil";
    else if (selecionado.value === "2") label.textContent = "Médio";
    else if (selecionado.value === "3") label.textContent = "Difícil";
}

document.querySelectorAll('input[name="radio"]').forEach(input => {
    input.addEventListener('change', atualizarLabel);
});

function selecionarModo(modo) {
    if (modo === "amigo") {
        localStorage.setItem("damaModo", "amigo");
        localStorage.removeItem("nivelSelecionado"); // limpa a dificuldade se for amigo
        window.location.href = "damaGame/dama-vs-player.html";
    } else if (modo === "bot") {
        localStorage.setItem("damaModo", "bot");
        document.getElementById("dificuldadeSection").style.display = "block";
    }
}

function jogarComBot() {
    const dificuldade = document.querySelector('input[name="radio"]:checked').value;
    let nivelTexto = "facil";
    if (dificuldade === "2") nivelTexto = "medio";
    else if (dificuldade === "3") nivelTexto = "dificil";

    localStorage.setItem("nivelSelecionado", nivelTexto);
    window.location.href = "damaGame/dama.html";
}
