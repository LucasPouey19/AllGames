let timer = 0;
let interval;

function voltar() {
    window.location.href = "../dama-dificuldade.html";
}

window.addEventListener("DOMContentLoaded", () => {
    userId = localStorage.getItem("userId");
    dificuldade = localStorage.getItem("nivelSelecionado") || "facil";
    document.getElementById("nivelDificuldade").innerText = "Dificuldade: " + dificuldade.charAt(0).toUpperCase() + dificuldade.slice(1);
    startTimer();

    const board = document.getElementById("chessboard");
    const turnoDisplay = document.getElementById("turno-display");
    let currentPlayer = 'red';
    let selectedPiece = null;
    let selectedPosition = null;
    const boardState = [];

    function startTimer() {
        interval = setInterval(() => {
            timer++;
            const min = String(Math.floor(timer / 60)).padStart(2, '0');
            const sec = String(timer % 60).padStart(2, '0');
            document.getElementById("timer").innerText = `${min}:${sec}`;
        }, 1000);
    }

    function createBoard() {
        board.innerHTML = '';
        boardState.length = 0;

        for (let row = 0; row < 8; row++) {
            boardState[row] = [];
            for (let col = 0; col < 8; col++) {
                const square = document.createElement('div');
                square.classList.add('square');
                square.dataset.row = row;
                square.dataset.col = col;

                if ((row + col) % 2 === 0) {
                    square.classList.add('white');
                } else {
                    square.classList.add('black');
                }

                if (row < 3 && (row + col) % 2 !== 0) {
                    addPiece(square, 'black');
                    boardState[row][col] = { color: 'black', king: false };
                } else if (row > 4 && (row + col) % 2 !== 0) {
                    addPiece(square, 'red');
                    boardState[row][col] = { color: 'red', king: false };
                } else {
                    boardState[row][col] = null;
                }

                square.addEventListener('click', () => handleSquareClick(row, col, square));
                board.appendChild(square);
            }
        }
        updateTurnDisplay();
    }

    function addPiece(square, color, king = false) {
        const piece = document.createElement('div');
        if (color === 'black') {
            piece.classList.add('piece', 'black-piece');
        } else {
            piece.classList.add('piece', color);
        }
        if (king) piece.innerText = '👑';
        square.appendChild(piece);
    }

    function updateTurnDisplay() {
        turnoDisplay.innerText = `Vez: ${currentPlayer === 'red' ? 'Vermelho' : 'Preto (Bot)'}`;
    }

    function getAllMandatoryCaptures(player) {
        const mandatory = [];
        for (let row = 0; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                const piece = boardState[row][col];
                if (piece && piece.color === player && canCapture(row, col)) {
                    mandatory.push({ row, col });
                }
            }
        }
        return mandatory;
    }

    function highlightMandatoryCapture() {
        document.querySelectorAll('.mandatory').forEach(sq => sq.classList.remove('mandatory'));
        const mandatory = getAllMandatoryCaptures(currentPlayer);
        mandatory.forEach(({ row, col }) => {
            const square = document.querySelector(`[data-row='${row}'][data-col='${col}']`);
            square.classList.add('mandatory');
        });
    }

    function handleSquareClick(row, col, square) {
        if (currentPlayer !== 'red') return;

        const cell = boardState[row][col];
        const mandatoryCaptures = getAllMandatoryCaptures('red');

        if (selectedPiece) {
            if (mandatoryCaptures.length > 0 &&
                !mandatoryCaptures.some(pos => pos.row === selectedPosition.row && pos.col === selectedPosition.col)) {
                alert("Você deve capturar com uma das peças indicadas!");
                highlightMandatoryCapture();
                clearSelection();
                return;
            }

            if (canMove(selectedPosition.row, selectedPosition.col, row, col)) {
                movePiece(selectedPosition.row, selectedPosition.col, row, col);
                checkForWin();
            }
            clearSelection();
        } else {
            if (cell && cell.color === currentPlayer) {
                if (mandatoryCaptures.length > 0 &&
                    !mandatoryCaptures.some(pos => pos.row === row && pos.col === col)) {
                    alert("Você deve capturar com uma das peças indicadas!");
                    highlightMandatoryCapture();
                    return;
                }
                selectPiece(row, col, square);
            }
        }
    }

    function selectPiece(row, col, square) {
        selectedPiece = square.querySelector('.piece');
        selectedPosition = { row, col };
        square.classList.add('selected');
    }

    function clearSelection() {
        document.querySelectorAll('.selected').forEach(sq => sq.classList.remove('selected'));
        selectedPiece = null;
        selectedPosition = null;
    }

    function canMove(fromRow, fromCol, toRow, toCol) {
        const piece = boardState[fromRow][fromCol];
        if (!piece) return false;

        const targetEmpty = boardState[toRow][toCol] === null;
        if (!targetEmpty) return false;

        const dx = toCol - fromCol;
        const dy = toRow - fromRow;
        const absDx = Math.abs(dx);
        const absDy = Math.abs(dy);

        if (piece.king) {
            if (absDx === absDy) {
                let captured = null;
                let stepX = dx / absDx;
                let stepY = dy / absDy;
                for (let i = 1; i < absDx; i++) {
                    const midRow = fromRow + stepY * i;
                    const midCol = fromCol + stepX * i;
                    const midPiece = boardState[midRow][midCol];
                    if (midPiece) {
                        if (midPiece.color === piece.color) return false;
                        if (captured) return false;
                        captured = { row: midRow, col: midCol };
                    }
                }
                return true;
            }
        } else {
            if (absDx === 1 && ((piece.color === 'red' && dy === -1) || (piece.color === 'black' && dy === 1))) {
                return true;
            }
            if (absDx === 2 && ((piece.color === 'red' && dy === -2) || (piece.color === 'black' && dy === 2))) {
                const midRow = fromRow + dy / 2;
                const midCol = fromCol + dx / 2;
                const midPiece = boardState[midRow][midCol];
                if (midPiece && midPiece.color !== piece.color) return true;
            }
        }
        return false;
    }

    function movePiece(fromRow, fromCol, toRow, toCol) {
        const piece = boardState[fromRow][fromCol];
        const fromSquare = document.querySelector(`[data-row='${fromRow}'][data-col='${fromCol}']`);
        const toSquare = document.querySelector(`[data-row='${toRow}'][data-col='${toCol}']`);
        const dx = toCol - fromCol;
        const dy = toRow - fromRow;

        toSquare.innerHTML = '';
        addPiece(toSquare, piece.color, piece.king);
        boardState[toRow][toCol] = { ...piece };
        boardState[fromRow][fromCol] = null;
        fromSquare.innerHTML = '';

        // Captura
        if (Math.abs(dx) === 2 || (piece.king && Math.abs(dx) > 1)) {
            let stepX = dx / Math.abs(dx);
            let stepY = dy / Math.abs(dy);
            for (let i = 1; i < Math.abs(dx); i++) {
                const midRow = fromRow + stepY * i;
                const midCol = fromCol + stepX * i;
                if (boardState[midRow][midCol] && boardState[midRow][midCol].color !== piece.color) {
                    boardState[midRow][midCol] = null;
                    const midSquare = document.querySelector(`[data-row='${midRow}'][data-col='${midCol}']`);
                    midSquare.innerHTML = '';
                    break;
                }
            }
            if (canCapture(toRow, toCol)) {
                setTimeout(() => {
                    autoCapture(toRow, toCol);
                }, 300);
                return;
            }
        }

        if (!piece.king) {
            if (piece.color === 'red' && toRow === 0) crownPiece(toRow, toCol);
            if (piece.color === 'black' && toRow === 7) crownPiece(toRow, toCol);
        }

        switchTurn();
    }

    function canCapture(row, col) {
        const piece = boardState[row][col];
        if (!piece) return false;

        const directions = piece.king
            ? [[1, 1], [1, -1], [-1, 1], [-1, -1]]
            : (piece.color === 'red' ? [[-1, -1], [-1, 1]] : [[1, -1], [1, 1]]);

        for (const [dy, dx] of directions) {
            const midRow = row + dy;
            const midCol = col + dx;
            const endRow = row + dy * 2;
            const endCol = col + dx * 2;

            if (
                midRow >= 0 && midRow < 8 &&
                midCol >= 0 && midCol < 8 &&
                endRow >= 0 && endRow < 8 &&
                endCol >= 0 && endCol < 8
            ) {
                const midPiece = boardState[midRow][midCol];
                if (midPiece && midPiece.color !== piece.color && boardState[endRow][endCol] === null) {
                    return true;
                }
            }
        }
        return false;
    }

    function autoCapture(row, col) {
        const piece = boardState[row][col];
        const directions = piece.king
            ? [[1, 1], [1, -1], [-1, 1], [-1, -1]]
            : (piece.color === 'red' ? [[-1, -1], [-1, 1]] : [[1, -1], [1, 1]]);

        for (const [dy, dx] of directions) {
            const midRow = row + dy;
            const midCol = col + dx;
            const endRow = row + dy * 2;
            const endCol = col + dx * 2;

            if (
                midRow >= 0 && midRow < 8 &&
                midCol >= 0 && midCol < 8 &&
                endRow >= 0 && endRow < 8 &&
                endCol >= 0 && endCol < 8
            ) {
                const midPiece = boardState[midRow][midCol];
                if (midPiece && midPiece.color !== piece.color && boardState[endRow][endCol] === null) {
                    movePiece(row, col, endRow, endCol);
                    return;
                }
            }
        }
        switchTurn();
    }

    function crownPiece(row, col) {
        const square = document.querySelector(`[data-row='${row}'][data-col='${col}']`);
        const piece = square.querySelector('.piece');
        piece.innerText = '👑';
        boardState[row][col].king = true;
    }

    function switchTurn() {
        currentPlayer = currentPlayer === 'red' ? 'black' : 'red';
        updateTurnDisplay();
        highlightMandatoryCapture();

        if (currentPlayer === 'black') {
            setTimeout(botMove, 500);
        }
    }

    function botMove() {
        const botMoves = [];

        const mandatory = getAllMandatoryCaptures('black');
        if (mandatory.length > 0) {
            for (const { row, col } of mandatory) {
                const dirs = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
                for (const [dy, dx] of dirs) {
                    const endRow = row + dy * 2;
                    const endCol = col + dx * 2;
                    if (endRow >= 0 && endRow < 8 && endCol >= 0 && endCol < 8 && canMove(row, col, endRow, endCol)) {
                        botMoves.push({ fromRow: row, fromCol: col, toRow: endRow, toCol: endCol });
                    }
                }
            }
        } else {
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const piece = boardState[row][col];
                    if (piece && piece.color === 'black') {
                        const dirs = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
                        for (const [dy, dx] of dirs) {
                            const newRow = row + dy;
                            const newCol = col + dx;
                            if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                                if (canMove(row, col, newRow, newCol)) {
                                    botMoves.push({ fromRow: row, fromCol: col, toRow: newRow, toCol: newCol });
                                }
                            }
                        }
                    }
                }
            }
        }

        if (botMoves.length > 0) {
            const move = botMoves[Math.floor(Math.random() * botMoves.length)];
            movePiece(move.fromRow, move.fromCol, move.toRow, move.toCol);
            checkForWin();
        } else {
            endGame('Vermelho');
        }
    }

    function checkForWin() {
        const reds = boardState.flat().filter(p => p && p.color === 'red');
        const blacks = boardState.flat().filter(p => p && p.color === 'black');

        if (reds.length === 0) endGame('Preto (Bot)');
        else if (blacks.length === 0) endGame('Vermelho');
    }

    function endGame(winner) {
        let pontos = 0;

        if (winner === "Vermelho") {
            alert("Você ganhou!");

            if (dificuldade === "facil") pontos = 1;
            else if (dificuldade === "medio") pontos = 2;
            else if (dificuldade === "dificil") pontos = 3;

        } else if (winner === "Preto (Bot)") {
            alert("O bot ganhou!");
            pontos = -1;
        }

        console.log("Dados enviados:", { userId, dificuldade, pontos });

        fetch("http://localhost:3005/dama/score", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userId, dificuldade, pontos }),
        })
            .then((res) => res.json())
            .then((data) => {
                console.log("Resposta do servidor:", data);
                const confirmarSaida = confirm(`Deseja voltar para a página de jogos?`);
                if (confirmarSaida) window.location.href = "../../jogoshome.html";
            })
            .catch((err) => {
                console.error("Erro ao salvar pontuação:", err);
                alert("Erro ao registrar pontuação. Tente novamente mais tarde.");
            });

        clearInterval(interval); // Parar o timer
    }


    createBoard();
});
