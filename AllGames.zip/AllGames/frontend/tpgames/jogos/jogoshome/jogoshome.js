function backHome() {
    window.location.href = "../../tpgames.html";
}

function sudokuGo() {
    window.location.href = "sudoku/sudoku-dificuldade.html";
}

function xadrezGo() {
    window.location.href = "xadrez/xadrez-dificuldade.html";
}

function velhaGo() {
    window.location.href = "velha/velha-dificuldade.html";
}

function damaGo() {
    window.location.href = "dama/dama-dificuldade.html";
}

function fourlineGo() {
    window.location.href = "fourline/fourline-dificuldade.html";
}

document.addEventListener("DOMContentLoaded", () => {
    const userId = localStorage.getItem("userId");

    if (!userId) {
        console.error("Usuário não identificado.");
        document.getElementById("pontosUsuario").innerText = "Erro";
        return;
    }

    fetch(`http://localhost:3005/usuarios/${userId}/pontos`)
        .then(response => {
            if (!response.ok) {
                throw new Error("Erro ao buscar os pontos");
            }
            return response.json();
        })
        .then(data => {
            document.getElementById("pontosUsuario").innerText = data.pontos;
        })
        .catch(error => {
            console.error(error);
            document.getElementById("pontosUsuario").innerText = "Erro";
        });
});
