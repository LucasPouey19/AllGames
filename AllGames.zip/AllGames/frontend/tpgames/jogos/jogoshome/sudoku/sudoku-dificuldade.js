// Atualiza o texto da label ao selecionar a dificuldade
document.querySelectorAll('input[name="radio"]').forEach(input => {
    input.addEventListener('change', atualizarLabel);
});

function atualizarLabel() {
    const selecionado = document.querySelector('input[name="radio"]:checked');
    const label = document.getElementById("labelDificuldade");

    if (selecionado.value == "1") label.textContent = "Fácil";
    else if (selecionado.value == "2") label.textContent = "Médio";
    else if (selecionado.value == "3") label.textContent = "Difícil";
}

function jogar() {
    const selecionado = document.querySelector('input[name="radio"]:checked');
    const dificuldade = selecionado.value;

    // Salvar a dificuldade no localStorage
    let nivelTexto = "facil";
    if (dificuldade === "2") nivelTexto = "medio";
    else if (dificuldade === "3") nivelTexto = "dificil";

    localStorage.setItem("nivelSelecionado", nivelTexto);

    // Redirecionar para a página do jogo
    window.location.href = `sudokuGame/sudoku.html`;
}


function selecionarDificuldade(nivel) {
    localStorage.setItem("nivelSelecionado", nivel);
    window.location.href = ""; // ou o nome real da sua página
}


function voltar() {
    window.location.href = "../jogoshome.html";
}

// Chamar a função ao carregar a página para setar a label corretamente
document.addEventListener("DOMContentLoaded", atualizarLabel);
