function voltar() {
    window.location.href = "../sudoku-dificuldade.html";
}

let board = [];
let solution = [];
let difficulty = "facil";
let userId = null;
let timerInterval;
let seconds = 0;
let vidas = 3;

function atualizarVidas() {
    const container = document.getElementById("vidas");
    container.innerHTML = "";
    for (let i = 0; i < 3; i++) {
        const icone = document.createElement("i");
        icone.classList.add("bi");
        if (i < vidas) {
            icone.classList.add("bi-heart-fill");
        } else {
            icone.classList.add("bi-heartbreak-fill");
        }
        container.appendChild(icone);
    }
}


const difficulties = {
    facil: 35,
    medio: 30,
    dificil: 25,
};

function startGame(dif, id) {
    let nomeExibicao = dif === "facil" ? "Fácil" : dif === "medio" ? "Médio" : "Difícil";
    document.getElementById("nivelDificuldade").textContent = `Dificuldade: ${nomeExibicao}`;

    difficulty = dif;
    userId = id;
    seconds = 0;
    clearInterval(timerInterval);
    timerInterval = setInterval(updateTimer, 1000);

    solution = generateFullSudoku(); // solução completa
    board = maskSudoku(solution, difficulties[dif]); // remove valores baseado na dificuldade
    renderBoard();
    vidas = 3;
    atualizarVidas();

}

function updateTimer() {
    seconds++;
    const mins = String(Math.floor(seconds / 60)).padStart(2, "0");
    const secs = String(seconds % 60).padStart(2, "0");
    document.getElementById("timer").textContent = `${mins}:${secs}`;
}

function renderBoard() {
    const grid = document.getElementById("tabuleiroSudoku");
    grid.innerHTML = "";
    for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
            const cell = document.createElement("input");
            cell.classList.add("cell");
            if (row % 3 === 0) cell.classList.add("top-border");
            if (col % 3 === 0) cell.classList.add("left-border");
            if ((col + 1) % 3 === 0) cell.classList.add("right-border");
            if ((row + 1) % 3 === 0) cell.classList.add("bottom-border");

            cell.dataset.row = row;
            cell.dataset.col = col;

            if (board[row][col] !== 0) {
                cell.value = board[row][col];
                cell.disabled = true;
                cell.classList.add("fixed");
            } else {
                cell.addEventListener("input", validateInput);

                // Adiciona o listener de foco aqui!
                cell.addEventListener("focus", () => {
                    inputAtivo = cell;
                });
            }

            grid.appendChild(cell);
        }
    }
}

function validateInput(e) {
    const input = e.target;
    const val = parseInt(input.value);
    const row = parseInt(input.dataset.row);
    const col = parseInt(input.dataset.col);

    if (!Number.isInteger(val) || val < 1 || val > 9) {
        input.value = "";
        return;
    }

    board[row][col] = val;
    if (val === solution[row][col]) {
        input.classList.add("correto");
        input.classList.remove("incorreto");
    } else {
        input.classList.add("incorreto");
        input.classList.remove("correto");

        vidas--;
        atualizarVidas();

        if (vidas === 0) {
            fetch("http://localhost:3005/sudoku/score", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ userId, difficulty, points: -1 }),
            }).then(res => res.json())
                .catch(err => console.error("Erro ao subtrair ponto na derrota:", err));

            setTimeout(() => {
                const jogarNovamente = confirm("Você perdeu! Deseja jogar de novo?");
                if (jogarNovamente) {
                    window.location.href = "../sudoku-dificuldade.html";
                } else {
                    window.location.href = "../../jogoshome.html";
                }
            }, 200);
        }

    }

    if (checkWin()) finishGame();
}

function checkWin() {
    for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
            if (board[row][col] !== solution[row][col]) {
                return false;
            }
        }
    }
    return true;
}

function finishGame() {
    clearInterval(timerInterval);
    const points = difficulty === "facil" ? 1 : difficulty === "medio" ? 2 : 3;

    fetch("http://localhost:3005/sudoku/score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, difficulty, points }),
    })
        .then((res) => res.json())
        .then(() => {
            const confirmar = confirm("Parabéns! Jogo concluído. Deseja voltar para a página de jogos?");
            if (confirmar) {
                window.location.href = "../../jogoshome.html";
            }
            // Se o usuário clicar "Não", nada acontece (permanece na tela)
        })
        .catch((err) => console.error("Erro ao salvar pontuação:", err));
}


// === Funções para geração de Sudoku aleatório e válido ===

function generateFullSudoku() {
    let grid = Array.from({ length: 9 }, () => Array(9).fill(0));
    fillGrid(grid);
    return grid;
}

function fillGrid(grid) {
    for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
            if (grid[row][col] === 0) {
                let nums = shuffleArray([...Array(9).keys()].map(n => n + 1));
                for (let num of nums) {
                    if (isSafe(grid, row, col, num)) {
                        grid[row][col] = num;
                        if (fillGrid(grid)) return true;
                        grid[row][col] = 0;
                    }
                }
                return false;
            }
        }
    }
    return true;
}

function maskSudoku(fullGrid, clues) {
    let masked = JSON.parse(JSON.stringify(fullGrid));
    let positions = shuffleArray([...Array(81).keys()]);
    let removed = 0;
    for (let pos of positions) {
        const row = Math.floor(pos / 9);
        const col = pos % 9;
        let backup = masked[row][col];
        masked[row][col] = 0;

        let testCopy = JSON.parse(JSON.stringify(masked));
        if (!hasUniqueSolution(testCopy)) {
            masked[row][col] = backup;
        } else {
            removed++;
        }

        if (81 - removed <= clues) break;
    }
    return masked;
}

function hasUniqueSolution(grid) {
    let count = 0;

    function solve(grid) {
        for (let row = 0; row < 9; row++) {
            for (let col = 0; col < 9; col++) {
                if (grid[row][col] === 0) {
                    for (let num = 1; num <= 9; num++) {
                        if (isSafe(grid, row, col, num)) {
                            grid[row][col] = num;
                            solve(grid);
                            grid[row][col] = 0;
                        }
                    }
                    return;
                }
            }
        }
        count++;
    }

    solve(grid);
    return count === 1;
}

function isSafe(grid, row, col, num) {
    for (let i = 0; i < 9; i++) {
        if (grid[row][i] === num || grid[i][col] === num) return false;
    }

    const boxRow = row - (row % 3);
    const boxCol = col - (col % 3);
    for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 3; c++) {
            if (grid[boxRow + r][boxCol + c] === num) return false;
        }
    }

    return true;
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// === Inicializa o jogo ao carregar a página ===
window.addEventListener("DOMContentLoaded", () => {
    const nivel = localStorage.getItem("nivelSelecionado") || "facil";
    const uid = localStorage.getItem("userId") || "1";
    startGame(nivel, uid);
});

let inputAtivo = null;

// Detectar o input ativo quando o usuário clica nele
document.querySelectorAll('#tabuleiro input').forEach(input => {
    input.addEventListener('focus', () => {
        inputAtivo = input;
    });
});

// Ações do teclado virtual
document.querySelectorAll('.tecla').forEach(botao => {
    botao.addEventListener('click', () => {
        if (!inputAtivo) return;

        if (botao.id === 'backspace') {
            inputAtivo.value = '';
            return;
        }

        const valor = botao.textContent.trim(); // garante que só números sejam capturados
        inputAtivo.value = valor;

        // dispara manualmente o evento input para acionar validateInput
        inputAtivo.dispatchEvent(new Event('input'));
    });
});
