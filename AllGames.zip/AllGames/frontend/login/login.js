function backHome() {
    window.location.href = "../inicial/index.html";
}

async function login() {
    const email = document.getElementById("emailInput").value;
    const password = document.getElementById("passwordInput").value;

    const resposta = await fetch("http://localhost:3005/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    });

    const dados = await resposta.json();

    if (resposta.ok) {
        alert(dados.message);
        // Salvar info do usuário ou redirecionar
        localStorage.setItem("userId", dados.user.id);   // <- guarda ID
        localStorage.setItem("userName", dados.user.name); // <- guarda nome
        window.location.href = "../tpgames/tpgames.html";

    } else {
        alert(dados.message);
    }
}