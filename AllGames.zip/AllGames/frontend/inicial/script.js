function goLogin() {
    window.location.href = "../login/login.html";
}

function goCadastro() {
    window.location.href = "../cadastro/cadastro.html";
}